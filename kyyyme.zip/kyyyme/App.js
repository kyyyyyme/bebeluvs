import React, { Component } from 'react';
import { View, Text, Image, ScrollView, StyleSheet } from 'react-native';

// Code example by Dr. Fuentes; May 21, 2023

export default class App extends Component {
  render() {
    return (
      <ScrollView>
        <View style={styles.container}>
          <Image
            source={{ uri: 'https://scontent.fmnl30-3.fna.fbcdn.net/v/t39.30808-1/454762944_526920446343172_6498199389171063782_n.jpg?stp=dst-jpg_s200x200&_nc_cat=104&ccb=1-7&_nc_sid=0ecb9b&_nc_eui2=AeGqm237rIfF85ntrlvEnFQS78DMJlHMGwTvwMwmUcwbBDTrkDEmNGU-HW0D6_aJKanQo03isdvOqvoQkNV0pbbv&_nc_ohc=sjzG_UviI64Q7kNvgHVcjGN&_nc_ht=scontent.fmnl30-3.fna&oh=00_AYAgHSeXyLDlPvM--1CTO6DuriDg3nQ_d4j03wnjwT_IPw&oe=66D44CEF' }}
            style={styles.image}
          />
          <Text style={styles.text}>Kyla Mae Alcera</Text> 
           <Text style={styles.text}>21</Text>
             <Text style={styles.text}>3rd year</Text>
        </View>

        <View style={styles.container}>
          <Image
            source={{ uri: '' }} // Replace with your own image URL
            style={styles.image}
          />
          <Text style={styles.text}></Text>
           
        </View>
      </ScrollView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 20,
  },
  image: {
    width: 200,
    height: 200,
  },
  text: {
    fontSize: 12,
    fontWeight: 'arial',
    textAlign: 'center',
    marginVertical: 2,
  },
});